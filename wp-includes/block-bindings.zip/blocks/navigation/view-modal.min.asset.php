<?php return array('dependencies' => array(), 'version' => 'b478fa3cd1475dec97d3');
