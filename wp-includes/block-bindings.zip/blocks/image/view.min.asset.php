<?php return array('dependencies' => array(), 'version' => 'ff354d5368d64857fef0');
