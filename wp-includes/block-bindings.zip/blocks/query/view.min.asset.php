<?php return array('dependencies' => array(), 'version' => '490915f92cc794ea16e1');
